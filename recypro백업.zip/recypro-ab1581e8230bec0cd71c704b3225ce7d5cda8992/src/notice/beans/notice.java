package notice.beans;

public class notice {

}
