package notice.beans;

public class noticeDAO {

}
