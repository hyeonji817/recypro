package declare.beans;

public class declare {

}
