package declare.beans;

public class declareDAO {

}
